import tkinter as tk
from tkhtmlview import HTMLLabel
import requests
from bs4 import BeautifulSoup

# Global variables for history tracking
history = []
current_position = -1

def cleanup_css(style_string):
    # Replace or remove unsupported CSS
    style_string = style_string.replace('text-align: justify;', 'text-align: left;')
    # Add other replacements as needed
    return style_string

def fetch_html(url):
    try:
        response = requests.get(url)
        return response.text
    except requests.RequestException as e:
        print("Error fetching the URL:", e)
        return "<p>Error loading content.</p>"

def simplify_html(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    # Remove script and style tags
    for script_or_style in soup(['script', 'style']):
        script_or_style.decompose()
    # Cleanup CSS in all styled tags
    for tag in soup.find_all(style=True):
        cleaned_styles = cleanup_css(tag['style'])
        tag['style'] = cleaned_styles
    return str(soup)

def load_url(url=None, from_history=False):
    global current_position
    if url is None:
        url = url_entry.get()
    html_content = fetch_html(url)
    simplified_content = simplify_html(html_content)
    html_label.set_html(simplified_content)

    if not from_history:
        # Update history and current position
        current_position += 1
        history[current_position:] = [url]  # Remove forward history when new URL is loaded
        back_button['state'] = 'normal' if current_position > 0 else 'disabled'
        forward_button['state'] = 'disabled'

def go_back():
    global current_position
    if current_position > 0:
        current_position -= 1
        load_url(history[current_position], from_history=True)
        forward_button['state'] = 'normal'

def go_forward():
    global current_position
    if current_position < len(history) - 1:
        current_position += 1
        load_url(history[current_position], from_history=True)
        back_button['state'] = 'normal'

# Create the main window
root = tk.Tk()
root.title("TKExplorer")
root.geometry("800x600")  # Width x Height

# Create a frame for the top bar
top_bar = tk.Frame(root)
top_bar.pack(side="top", fill="x")

# URL Entry
url_entry = tk.Entry(top_bar)
url_entry.pack(side="left", expand=True, fill="x")

# buttons
load_button = tk.Button(top_bar, text="Load URL", command=load_url)
load_button.pack(side="left", padx=2)
back_button = tk.Button(top_bar, text="Back", command=go_back, state='disabled')
back_button.pack(side="left", padx=2)
forward_button = tk.Button(top_bar, text="Forward", command=go_forward, state='disabled')
forward_button.pack(side="left", padx=2)



# Create an HTMLLabel to display HTML content
html_content = """
<!DOCTYPE html>
<html>
<body>

<h1 style="color: navy;">Welcome to TKExplorer</h1>
<p style="font-family: Arial; color: black;">An extremely lightweight browser running TkHTMLview through Python and Tkinter.</p>
<p style="font-family: Arial; color: black;">How to use: Type in the exact web address, and click 'Load URL'. Use scroll bar to move up and down the page. Back and Forward are for going to previous webpages. Disclaimer- This browser does not have any advanced security features. In fact, the best security feature is probably that it does not load JavaScript.</p>
<p style="font-family: Arial; color: black;">Was made in just a few hours, thanks to a few very helpful Python libraries. I could add more features, but due to current limitations of TkHTMLview and Tkinter I would like to stop here and just leave it as a simple showcase of the technology. Even if I was fine with the limitations, I have no idea how to improve this security wise, nor make links openable within TKExplorer.</p>
<p style="font-family: Arial; color: black;">About the Python libraries I used: BeautifulSoup4 allowed me to greatly improve the display of the webpages, being able to use Tkinter for the basis of the project was super convenient, and TkHTMLview made the 'browser' super easy to start working on.</p>
<p style="font-family: Arial; color: black;">I picked these libaries to make this project more doable, as making a full fledged, competitive browser by myself is virtually impossible. But making this and looking into other browsers has given me a better idea of what assembling a product with major shortcuts is like.</p>
<a href="https://visitpaul.com" style="color: blue;">Visit the creator's site, VisitPaul.com</a>

</body>
</html>
"""
html_label = HTMLLabel(root, html=html_content)
html_label.pack(fill="both", expand=True)

# Run the application
root.mainloop()
