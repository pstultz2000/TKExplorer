TKExplorer - A Simple Python-Based Browser
Created by Paul Stultz

---------------------------------

Disclaimer: TKExplorer has minimal security features. It's designed to demonstrate the capabilities of Python 3.12.1 and existing libraries in creating a basic browser. It cannot run JavaScript and is intended for safe, well-established websites.

How to Run: 
- On Windows, unzip the package and double-click 'launch.bat'. Compatible with versions of Windows that support Python 3.12.1.

Features:
- Content that cannot be properly displayed is not loaded, thanks to BeautifulSoup4.
- Supports HTTPS via TkHTMLview, offering secure connections despite its simplicity.
- Graphical interface is a step above text browsers like Lynx.
- Back and Forward buttons for simple navigation.

This project is a showcase of rapid development using Python and is not intended for practical web browsing.

Feedback and Contact:
- VisitPaul.com

I hope you enjoy exploring TKExplorer!
